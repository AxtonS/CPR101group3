#ifndef _TOKENIZING_H
#define _TOKENIZING_H

#include <stdio.h>
#include <string.h>

void tokenizing(void);

int main() {
    // Call your tokenizing function or include it in your main function
    tokenizing();

    return 0;
}
#endif 
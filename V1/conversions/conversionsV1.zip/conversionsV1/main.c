#include "converting.h"

int main(void)
{
	converting();
	return 0;
}
#ifndef _CONVERTING_H_
#define _CONVERTING_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// User inputs a number as a string, then it is returned as an int
void converting(void);

#endif